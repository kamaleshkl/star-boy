# READ THIS
We are aware of the fact that the Discord server has been deleted. Please do not post additional issues talking about this. If your issue is not related to the deletion of the server, please delete this text and enter in your issue as normal.

## About the issue tracker
The GitHub issue tracker is for reporting problems in bot code only. We are unable to assist you in problems arising from user error or your own configuration issues.